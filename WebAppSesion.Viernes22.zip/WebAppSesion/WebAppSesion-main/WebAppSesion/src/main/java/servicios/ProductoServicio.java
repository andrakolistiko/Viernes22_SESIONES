package servicios;

import modelo.Productos;

import java.util.List;

public interface ProductoServicio {
    List<Productos> listar();
}