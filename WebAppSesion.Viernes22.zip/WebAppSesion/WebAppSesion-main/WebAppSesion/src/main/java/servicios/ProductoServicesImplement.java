package servicios;

import modelo.Productos;

import java.util.Arrays;
import java.util.List;

public class ProductoServicesImplement implements ProductoServicio {
    @Override
    public List<Productos> listar() {
        return Arrays.asList(
                new Productos(1, "Laptop", "Electrónica", 1200.75),
                new Productos(2, "Silla de oficina", "Muebles", 150.50),
                new Productos(3, "Libros de texto", "Educación", 35.99),
                new Productos(4, "Televisor", "Electrodomésticos", 800.00),
                new Productos(5, "Cafetera", "Cocina", 45.00)
        );
    }
}